#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals, division, absolute_import, print_function

try:
    from sigil_bs4 import BeautifulSoup
except:
    from bs4 import BeautifulSoup

import re

def run(bk):
    nav_id = ncx_id = None
    # get ncx and nav file ids (default: ncx & navid)
    try:
        # Sigil 0.8.9 and higher
        for (id, href, mime, properties) in bk.manifest_epub3_iter():
            if properties == 'nav':
                nav_id = id
            if mime == 'application/x-dtbncx+xml':
                ncx_id = id
    except:
        # fallback for Sigil 0.8.7 
        for (id, href, mime) in bk.manifest_iter():
            if mime == 'application/x-dtbncx+xml':
                ncx_id = id

    ncx_pagelist = '  <pageList>\n    <navLabel>\n      <text>Pages</text>\n    </navLabel>\n'
    nav_pagelist = '    <nav epub:type="page-list" id="page-list">\n      <ol>\n'
    page_targets = 0
       
    # get all files in the spine
    for (html_id, linear) in bk.getspine():
        mime = bk.id_to_mime(html_id)
        
        # process only html files
        if mime == 'application/xhtml+xml':
            html = bk.readfile(html_id)
            
            # load html code into BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            
            # find pagebreaks
            page_numbers = soup.find_all('span', {'epub:type' : 'pagebreak'})
            if not page_numbers:
                print('\nNo page number targets found in ' + bk.id_to_href(html_id))
            else:
                page_targets += len(page_numbers)
                print('\n' + str(len(page_numbers)) + ' page number targets found in ' + bk.id_to_href(html_id))
            
            # add pagelist entries to pagelist
            for page_number in page_numbers:
                id = page_number['id']
                if page_number.has_attr('title'):
                    title = page_number['title']
                else:
                    title = page_number.contents[0]
                    
                ncx_pagelist += '    <pageTarget id="' + id + '" type="normal" value="' + title + '">\n      <navLabel>\n        <text>' + title + '</text>\n      </navLabel>\n' + '      <content src="' + bk.id_to_href(html_id) + '#' + id + '"/>\n    </pageTarget>\n'
                nav_pagelist += '        <li>\n          <a href="../' + bk.id_to_href(html_id) + '#' + id + '">' + title + '</a>\n        </li>\n'
    
    # add/replace NCX pagelist section
    if page_targets:
        ncx_pagelist += '  </pageList>'
        if ncx_id: 
            # get ncx contents
            ncx = bk.readfile(ncx_id)
            # delete existing pagelist
            ncx = re.sub('\s*\<pageList\>.+?\<\/pageList\>\s*', '', ncx, flags = re.DOTALL)
            # add new pagelist
            ncx = ncx.replace('</ncx>', '\n' + ncx_pagelist + '\n</ncx>')
            # update ncx file
            bk.writefile(ncx_id, ncx)
            print('\n' + str(page_targets) + ' page number targets found.\nNCX file updated. ')
        else:
            print('\nNCX file couldn\'t be found and updated.')
    else:
        print('\nNo page number targets found.\nNCX file not updated')

    # add/replace NAV pagelist section
    if page_targets:
        nav_pagelist += '      </ol>\n    </nav>'
        if nav_id:
            # get nav contents
            nav = bk.readfile(nav_id)
            # delete existing pagelist
            nav = re.sub('\s*\<nav epub:type="page-list"[^>]*\>.+?\<\/nav\>\s*', '', nav, flags = re.DOTALL)
            # add new pagelist
            nav = nav.replace('</body>', '\n' + nav_pagelist + '\n  </body>')
            # update nav file
            bk.writefile(nav_id, nav)
            print('NAV file updated.')
    
    print('\nPlease click OK to close the Plugin Runner window.')
    
    return 0


def main():
    print('I reached main when I should not have\n')
    return -1

if __name__ == "__main__":
    sys.exit(main())
